str1 = input("Enter your string")
vowel = 0
consonant = 0
for i in str1:
    if (i=='a' or i=='e' or i=='i' or i=='o' or i=='u' ) or (i=='A' or i=='E' or i=='I' or i=='O' or i=='U'):
        vowel = vowel + 1
    else:
        consonant = consonant + 1
print("Total number of vowels in given string is ", vowel)
print("Total number of consonant in given string is ", consonant)