def transpose_matrix(matrix):
    rows = len(matrix)
    cols = len(matrix[0])
    transposed = [[0] * rows for _ in range(cols)]
    for i in range(rows):
        for j in range(cols):
            transposed[j][i] = matrix[i][j]

    return transposed

def read_matrix():
    while True:
        try:
            rows = int(input("Enter the number of rows: "))
            cols = int(input("Enter the number of columns: "))

            matrix = []
            for i in range(rows):
                row = list(map(int, input(f"Enter row {i + 1} (space-separated values): ").split()))
                if len(row) != cols:
                    print(f"Error: Row {i + 1} must have exactly {cols} columns.")
                    return None
                matrix.append(row)

            return matrix
        except ValueError:
            print("Error: Please enter valid integers.")

def print_matrix(matrix):
    for row in matrix:
        print(" ".join(map(str, row)))

def main():
    print("Enter the matrix:")
    matrix = read_matrix()
    if matrix is None:
        return
    transposed = transpose_matrix(matrix)
    print("Transposed matrix:")
    print_matrix(transposed)

if __name__ == "__main__":
    main()
