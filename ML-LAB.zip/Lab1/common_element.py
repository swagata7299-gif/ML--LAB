def common_elements(list1, list2):
    set1 = set(list1)
    set2 = set(list2)
    common_elements = set1.intersection(set2)
    return len(common_elements)
def read_list(prompt):
    while True:
        try:
            user_input = input(prompt)
            integer_list = list(map(int, user_input.split()))
            return integer_list
        except ValueError:
            print("Error: Please enter valid integers separated by spaces.")

def main():
    print("Enter the first list of integers (space-separated):")
    list1 = read_list("List 1: ")
    print("Enter the second list of integers (space-separated):")
    list2 = read_list("List 2: ")
    common_count = common_elements(list1, list2)
    print(f"Number of common elements: {common_count}")

if __name__ == "__main__":
    main()
