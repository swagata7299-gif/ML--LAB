def read_matrix(rows, cols):
    matrix = []
    for i in range(rows):
        while True:
            try:
                row = list(map(int, input(f"Enter row {i + 1} (space-separated values): ").split()))
                if len(row) != cols:
                    print(f"Error: Row {i + 1} must have exactly {cols} columns.")
                else:
                    matrix.append(row)
                    break
            except ValueError:
                print("Error: Please enter valid integers.")
    return matrix


def multiply_matrices(A, B):
    m = len(A)
    n = len(A[0])
    p = len(B)
    q = len(B[0])
    if n != p:
        return "Error: Number of columns of A must be equal to number of rows of B"
    result = [[0] * q for _ in range(m)]
    for i in range(m):
        for j in range(q):
            for k in range(n):
                result[i][j] += A[i][k] * B[k][j]

    return result


def print_matrix(matrix):
    for row in matrix:
        print(" ".join(map(str, row)))


def main():
    print("Matrix A:")
    m = int(input("Enter the number of rows for matrix A: "))
    n = int(input("Enter the number of columns for matrix A: "))
    print("Enter the elements of matrix A:")
    A = read_matrix(m, n)

    print("Matrix B:")
    p = int(input("Enter the number of rows for matrix B: "))
    q = int(input("Enter the number of columns for matrix B: "))
    print("Enter the elements of matrix B:")
    B = read_matrix(p, q)
    product = multiply_matrices(A, B)
    if isinstance(product, str):
        print(product)
    else:
        print("Product matrix:")
        print_matrix(product)


if __name__ == "__main__":
    main()
