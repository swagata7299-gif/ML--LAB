import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import MinMaxScaler

# Load the data from the CSV file
data = pd.read_csv('image_datasets_1.csv')

# Extract features (mean_R and mean_G) and the target label
X_train = data[['mean_R', 'mean_G']].values
y_train = data['label'].apply(lambda x: 0 if x == 'real' else 1).values  # Convert labels to numerical (0 for real, 1 for fake)

# Normalize the data to fit the test points within the same scale
scaler = MinMaxScaler(feature_range=(0, 10))
X_train_scaled = scaler.fit_transform(X_train)

# Generate test data within the same range as the training data
x_values = np.arange(0, 10.1, 0.1)
y_values = np.arange(0, 10.1, 0.1)
X_test, Y_test = np.meshgrid(x_values, y_values)
X_test = X_test.flatten()
Y_test = Y_test.flatten()
test_points = np.vstack((X_test, Y_test)).T

# List of k values to try
k_values = [1, 3, 5, 10, 15]

# Create subplots
fig, axes = plt.subplots(1, len(k_values), figsize=(20, 5))

# Plot the results for each k in a separate subplot
for i, k in enumerate(k_values):
    # Create and train the kNN model
    knn_model = KNeighborsClassifier(n_neighbors=k)
    knn_model.fit(X_train_scaled, y_train)

    # Predict the class for each test point
    predicted_classes = knn_model.predict(test_points)

    # Plot the classified test data
    ax = axes[i]
    scatter = ax.scatter(X_test, Y_test, c=predicted_classes, cmap='coolwarm', s=10)
    
    # Plot the scaled training data
    ax.scatter(X_train_scaled[:, 0], X_train_scaled[:, 1], c=y_train, cmap='coolwarm', edgecolors='k', s=100, label='Training Data')
    
    ax.set_title(f'k = {k}')
    ax.set_xlabel('Mean R (Scaled)')
    ax.set_ylabel('Mean G (Scaled)')
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 10)

# Add a colorbar to the last subplot
fig.colorbar(scatter, ax=axes, orientation='horizontal', fraction=0.02, pad=0.1)

plt.suptitle('kNN Classifier Output on Test Data for Different k Values')
plt.tight_layout(rect=[0, 0.03, 1, 0.95])
plt.show()
