import numpy as np
import pandas as pd
from sklearn.model_selection import GridSearchCV
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.model_selection import RandomizedSearchCV
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split

# Load data from CSV
data = pd.read_csv('image_datasets_1.csv')

# Extract features and labels
X = data[['mean_R', 'mean_G', 'mean_B']].values
y = LabelEncoder().fit_transform(data['label'])

# Split the data into training and validation sets
X_train, X_valid, y_train, y_valid = train_test_split(X, y, test_size=0.2, random_state=42)

# Define the parameter grid
param_grid = {
    'n_neighbors': np.arange(1, 21),  # Search k values from 1 to 20
    'algorithm': ['auto', 'ball_tree', 'kd_tree', 'brute']  # Different algorithms
}

# Set up GridSearchCV
grid_search = GridSearchCV(KNeighborsClassifier(), param_grid, cv=5, scoring='accuracy', n_jobs=-1)

# Fit GridSearchCV
grid_search.fit(X_train, y_train)

# Best parameters and score
print("Best parameters found: ", grid_search.best_params_)
print("Best cross-validation score: {:.2f}".format(grid_search.best_score_))

# Evaluate on validation set
best_knn = grid_search.best_estimator_
valid_score = best_knn.score(X_valid, y_valid)
print("Validation set score with best parameters: {:.2f}".format(valid_score))


# Extract features and labels
X = data[['mean_R', 'mean_G', 'mean_B']].values
y = LabelEncoder().fit_transform(data['label'])

# Split the data into training and validation sets
X_train, X_valid, y_train, y_valid = train_test_split(X, y, test_size=0.2, random_state=42)

# Define the parameter distribution
param_dist = {
    'n_neighbors': np.arange(1, 21),  # Random search for k values from 1 to 20
    'algorithm': ['auto', 'ball_tree', 'kd_tree', 'brute']  # Different algorithms
}

# Set up RandomizedSearchCV
random_search = RandomizedSearchCV(KNeighborsClassifier(), param_distributions=param_dist, 
                                   n_iter=10, cv=5, scoring='accuracy', n_jobs=-1, random_state=42)

# Fit RandomizedSearchCV
random_search.fit(X_train, y_train)

# Best parameters and score
print("Best parameters found: ", random_search.best_params_)
print("Best cross-validation score: {:.2f}".format(random_search.best_score_))

# Evaluate on validation set
best_knn = random_search.best_estimator_
valid_score = best_knn.score(X_valid, y_valid)
print("Validation set score with best parameters: {:.2f}".format(valid_score))