import numpy as np
import matplotlib.pyplot as plt
from sklearn.neighbors import KNeighborsClassifier
from sklearn.datasets import make_classification  # Example dataset

# Generate a synthetic dataset for demonstration
X_train, y_train = make_classification(n_samples=500, n_features=2, n_informative=2, n_redundant=0, n_repeated=0, n_classes=2, random_state=0)

# Generate test data
x_values = np.arange(0, 10.1, 0.1)
y_values = np.arange(0, 10.1, 0.1)
X_test, Y_test = np.meshgrid(x_values, y_values)
X_test = X_test.flatten()
Y_test = Y_test.flatten()
test_points = np.vstack((X_test, Y_test)).T

# List of k values to try
k_values = [1, 3, 5, 10, 15]

# Create subplots
fig, axes = plt.subplots(1, len(k_values), figsize=(20, 5))

# Plot the results for each k in a separate subplot
for i, k in enumerate(k_values):
    # Create and train the kNN model
    knn_model = KNeighborsClassifier(n_neighbors=k)
    knn_model.fit(X_train, y_train)

    # Predict the class for each test point
    predicted_classes = knn_model.predict(test_points)

    # Plot the classified test data
    ax = axes[i]
    scatter = ax.scatter(X_test, Y_test, c=predicted_classes, cmap='coolwarm', s=10)
    
    # Plot the training data
    ax.scatter(X_train[:, 0], X_train[:, 1], c=y_train, cmap='coolwarm', edgecolors='k', s=100, label='Training Data')
    
    ax.set_title(f'k = {k}')
    ax.set_xlabel('X')
    ax.set_ylabel('Y')

# Add a colorbar to the last subplot
fig.colorbar(scatter, ax=axes, orientation='horizontal', fraction=0.02, pad=0.1)

plt.suptitle('kNN Classifier Output on Test Data for Different k Values')
plt.tight_layout(rect=[0, 0.03, 1, 0.95])
plt.show()
