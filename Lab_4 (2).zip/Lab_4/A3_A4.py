import numpy as np
import matplotlib.pyplot as plt
from sklearn.neighbors import KNeighborsClassifier

# Step 1: Generate Training Data
np.random.seed(0)  # For reproducibility

# Generate 20 random data points
X_train = np.random.uniform(1, 10, (20, 2))
# Randomly assign these points to class0 (blue) and class1 (red)
y_train = np.random.randint(0, 2, 20)

# Step 2: Scatter Plot of Training Data
plt.figure(figsize=(10, 6))
plt.scatter(X_train[y_train == 0][:, 0], X_train[y_train == 0][:, 1], color='blue', label='Class 0')
plt.scatter(X_train[y_train == 1][:, 0], X_train[y_train == 1][:, 1], color='red', label='Class 1')
plt.xlabel('X')
plt.ylabel('Y')
plt.title('Training Data')
plt.legend()
plt.show()

# Step 3: Generate Test Data
x_values = np.arange(0, 10.1, 0.1)
y_values = np.arange(0, 10.1, 0.1)
X_test, Y_test = np.meshgrid(x_values, y_values)
X_test = X_test.flatten()
Y_test = Y_test.flatten()
test_points = np.vstack((X_test, Y_test)).T

# Step 4: Classify Test Data Using kNN
# Create and train the kNN model
knn_model = KNeighborsClassifier(n_neighbors=3)
knn_model.fit(X_train, y_train)

# Predict the class for each test point
predicted_classes = knn_model.predict(test_points)

# Plot the classified test data
plt.figure(figsize=(10, 8))
plt.scatter(X_test, Y_test, c=predicted_classes, cmap='coolwarm', s=10)
plt.colorbar(label='Predicted Class')
plt.xlabel('X')
plt.ylabel('Y')
plt.title('kNN Classifier Output on Test Data')
plt.show()