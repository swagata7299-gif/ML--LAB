import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import LabelEncoder

# Load data from CSV
data = pd.read_csv('image_datasets_1.csv')

# Extract features and labels
X_train = data[['mean_R', 'mean_G', 'mean_B']].values

# Map labels to numerical values
label_encoder = LabelEncoder()
y_train = label_encoder.fit_transform(data['label'])

# Scatter Plot of Training Data (using only the first 2 features for 2D plot)
plt.figure(figsize=(10, 6))
plt.scatter(X_train[y_train == 0][:, 0], X_train[y_train == 0][:, 1], color='blue', label='Real')
plt.scatter(X_train[y_train == 1][:, 0], X_train[y_train == 1][:, 1], color='red', label='Fake')
plt.xlabel('Mean R')
plt.ylabel('Mean G')
plt.title('Training Data')
plt.legend()
plt.show()

# Extract features and labels
X_train = data[['mean_R', 'mean_G', 'mean_B']].values

# Map labels to numerical values
label_encoder = LabelEncoder()
y_train = label_encoder.fit_transform(data['label'])

# Create and train the kNN model
knn_model = KNeighborsClassifier(n_neighbors=3)
knn_model.fit(X_train, y_train)

# Generate Test Data (using the same range as feature values, 0 to 255)
x_values = np.arange(0, 256, 10)  # Adjust the step size for better performance
y_values = np.arange(0, 256, 10)
z_values = np.arange(0, 256, 10)
X_test, Y_test, Z_test = np.meshgrid(x_values, y_values, z_values)
X_test = X_test.flatten()
Y_test = Y_test.flatten()
Z_test = Z_test.flatten()
test_points = np.vstack((X_test, Y_test, Z_test)).T

# Predict the class for each test point
predicted_classes = knn_model.predict(test_points)

# Plot the classified test data
# For 3D plotting, we'll use a scatter plot with color coding
from mpl_toolkits.mplot3d import Axes3D

fig = plt.figure(figsize=(12, 10))
ax = fig.add_subplot(111, projection='3d')
scatter = ax.scatter(X_test, Y_test, Z_test, c=predicted_classes, cmap='coolwarm', s=5)
ax.set_xlabel('Mean R')
ax.set_ylabel('Mean G')
ax.set_zlabel('Mean B')
ax.set_title('kNN Classifier Output on Test Data')
plt.colorbar(scatter, label='Predicted Class')
plt.show()