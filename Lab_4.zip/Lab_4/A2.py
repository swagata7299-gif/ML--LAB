import pandas as pd

# Read a specific sheet by name or index
df = pd.read_excel("C:/Users/User/Downloads/Lab Session Data.xlsx", sheet_name='Purchase data')

# Display the first few rows of the dataframe
print(df.head())

import numpy as np
from sklearn.metrics import mean_squared_error, mean_absolute_percentage_error, r2_score

# Actual prices (from your provided data)
actual = [110, 280, 167, 271, 274, 148, 198]

# Example predicted prices (replace these with your predicted values)
predicted = [112, 275, 170, 268, 276, 150, 200]

# Convert lists to numpy arrays
actual = np.array(actual)
predicted = np.array(predicted)

# Calculate MSE
mse = mean_squared_error(actual, predicted)

# Calculate RMSE
rmse = np.sqrt(mse)

# Calculate MAPE (in percentage)
mape = mean_absolute_percentage_error(actual, predicted) * 100

# Calculate R-squared score
r2 = r2_score(actual, predicted)

# Print the results
print(f"MSE: {mse}")
print(f"RMSE: {rmse}")
print(f"MAPE: {mape}%")
print(f"R2 Score: {r2}")
