import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import confusion_matrix, classification_report
import matplotlib.pyplot as plt

# Function to load dataset and split it
def split_dataset(csv_filename, test_size=0.3):
    # Load the dataset
    df = pd.read_csv(csv_filename)
    
    # Extract features and labels
    features = df.iloc[:, :-2].values.astype(float)  # All columns except the last two
    labels = df.iloc[:, -2].values  # Second to last column
    
    # Split dataset into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(features, labels, test_size=test_size, random_state=42)
    
    return X_train, X_test, y_train, y_test

# Load and split dataset
csv_filename = 'image_dataset.csv'  # Replace with your CSV file name
X_train, X_test, y_train, y_test = split_dataset(csv_filename)

# Feature scaling
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Train kNN classifier with k=3 (or any k you want to evaluate)
k = 3
neigh = KNeighborsClassifier(n_neighbors=k)
neigh.fit(X_train_scaled, y_train)

# Predict on training and test sets
y_train_pred = neigh.predict(X_train_scaled)
y_test_pred = neigh.predict(X_test_scaled)

# Compute confusion matrix
conf_matrix_train = confusion_matrix(y_train, y_train_pred)
conf_matrix_test = confusion_matrix(y_test, y_test_pred)

# Print confusion matrix
print("Confusion Matrix for Training Data:")
print(conf_matrix_train)
print("\nConfusion Matrix for Test Data:")
print(conf_matrix_test)

# Compute classification reports (precision, recall, F1-score)
print("\nClassification Report for Training Data:")
print(classification_report(y_train, y_train_pred))
print("\nClassification Report for Test Data:")
print(classification_report(y_test, y_test_pred))

# Plot confusion matrix for better visualization
import seaborn as sns

def plot_confusion_matrix(cm, labels):
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=labels, yticklabels=labels)
    plt.xlabel('Predicted Label')
    plt.ylabel('True Label')
    plt.title('Confusion Matrix')
    plt.show()

# Assuming binary classification for labels; adjust if needed
labels = np.unique(y_test)

print("\nConfusion Matrix Plot for Training Data:")
plot_confusion_matrix(conf_matrix_train, labels)
print("\nConfusion Matrix Plot for Test Data:")
plot_confusion_matrix(conf_matrix_test, labels)
