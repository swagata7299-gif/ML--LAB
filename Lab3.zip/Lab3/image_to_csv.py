import os
import cv2
import numpy as np
import pandas as pd

# Function to load and preprocess images
def load_images_from_folder(folder):
    images = []
    filenames = []
    for filename in os.listdir(folder):
        img_path = os.path.join(folder, filename)
        img = cv2.imread(img_path)
        if img is not None:
            img = cv2.resize(img, (224, 224))  # Resize to a standard size
            images.append(img)
            filenames.append(filename)
    return images, filenames

# Function to extract basic features (mean pixel values)
def extract_features(images):
    features = []
    for img in images:
        mean_value = np.mean(img, axis=(0, 1))  # Mean of RGB channels
        features.append(mean_value)
    return np.array(features)

# Convert dataset to CSV
def convert_dataset_to_csv(base_folder, csv_filename):
    data = []
    for subfolder in ['real', 'fake']:
        folder_path = os.path.join(base_folder, subfolder)
        images, filenames = load_images_from_folder(folder_path)
        features = extract_features(images)
        labels = [subfolder] * len(features)
        
        for feature, label, filename in zip(features, labels, filenames):
            data.append(np.append(feature, [label, filename]))
    
    # Create DataFrame and save to CSV
    columns = ['mean_R', 'mean_G', 'mean_B', 'label', 'filename']
    df = pd.DataFrame(data, columns=columns)
    df.to_csv(csv_filename, index=False)
    print(f"Dataset converted to {csv_filename}")

# Paths
base_folder = 'C:/Users/ru368/OneDrive/Desktop/try_ML(1)/data/train'       # Replace with the actual path to your dataset folder
csv_filename = 'image_dataset.csv'  # Replace with the desired name for your CSV file

# Convert dataset to CSV
convert_dataset_to_csv(base_folder, csv_filename)
