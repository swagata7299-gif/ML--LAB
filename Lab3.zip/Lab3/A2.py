import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Function to analyze a specific feature
def analyze_feature(csv_filename, feature_index):
    df = pd.read_csv(csv_filename)
    
    # Extract features and labels
    features = df.iloc[:, :-2].values.astype(float)  # All columns except the last two
    labels = df.iloc[:, -2].values  # Second to last column
    
    # Select the feature to analyze
    feature_data = features[:, feature_index]
    
    # Calculate mean and variance
    feature_mean = np.mean(feature_data)
    feature_variance = np.var(feature_data)
    
    # Plot histogram
    plt.figure(figsize=(10, 6))
    plt.hist(feature_data, bins=30, edgecolor='black', alpha=0.7)
    plt.title(f'Histogram of Feature {feature_index}')
    plt.xlabel('Feature Value')
    plt.ylabel('Frequency')
    plt.grid(True)
    plt.show()
    
    # Print mean and variance
    print(f"Feature {feature_index} Mean: {feature_mean}")
    print(f"Feature {feature_index} Variance: {feature_variance}")

# Paths
csv_filename = 'image_dataset.csv'  # Replace with your CSV file name

# Index of the feature to analyze (e.g., 0 for the first feature)
feature_index = 0  # Change this index to select a different feature

# Analyze the specified feature
analyze_feature(csv_filename, feature_index)
