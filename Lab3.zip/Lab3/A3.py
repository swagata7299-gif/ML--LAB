import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Function to calculate Minkowski distance
def minkowski_distance(x, y, r):
    return np.linalg.norm(x - y, ord=r)

# Function to analyze distances for varying r
def analyze_minkowski_distance(csv_filename, index1, index2):
    df = pd.read_csv(csv_filename)
    
    # Extract features
    features = df.iloc[:, :-2].values.astype(float)  # All columns except the last two
    
    # Select two feature vectors
    vector1 = features[index1]
    vector2 = features[index2]
    
    # Calculate Minkowski distances for r from 1 to 10
    r_values = np.arange(1, 11)
    distances = [minkowski_distance(vector1, vector2, r) for r in r_values]
    
    # Plot the distances
    plt.figure(figsize=(10, 6))
    plt.plot(r_values, distances, marker='o', linestyle='-', color='b')
    plt.title('Minkowski Distance Between Two Feature Vectors')
    plt.xlabel('r (Order)')
    plt.ylabel('Distance')
    plt.grid(True)
    plt.xticks(r_values)
    plt.show()
    
    # Print distances
    for r, distance in zip(r_values, distances):
        print(f"r = {r}, Distance = {distance}")

# Paths
csv_filename = 'image_dataset.csv'  # Replace with your CSV file name

# Indexes of the two feature vectors to compare (e.g., 0 and 1)
index1 = 0  # Index of the first feature vector
index2 = 1  # Index of the second feature vector

# Analyze Minkowski distance
analyze_minkowski_distance(csv_filename, index1, index2)
