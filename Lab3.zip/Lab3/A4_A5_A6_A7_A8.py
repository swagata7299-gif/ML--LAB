import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import matplotlib.pyplot as plt

# Function to load dataset and split it
def split_dataset(csv_filename, test_size=0.3):
    # Load the dataset
    df = pd.read_csv(csv_filename)
    
    # Extract features and labels
    features = df.iloc[:, :-2].values.astype(float)  # All columns except the last two
    labels = df.iloc[:, -2].values  # Second to last column
    
    # Split dataset into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(features, labels, test_size=test_size, random_state=42)
    
    return X_train, X_test, y_train, y_test

# Load and split dataset
csv_filename = 'image_dataset.csv'  # Replace with your CSV file name
X_train, X_test, y_train, y_test = split_dataset(csv_filename)

# Feature scaling
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Train kNN classifier with k=3
k = 3
knn = KNeighborsClassifier(n_neighbors=k)
knn.fit(X_train_scaled, y_train)

# Test the accuracy of the classifier
accuracy = knn.score(X_test_scaled, y_test)

# Predict on the test set
y_pred = knn.predict(X_test_scaled)

# Evaluate the classifier
conf_matrix = confusion_matrix(y_test, y_pred)
class_report = classification_report(y_test, y_pred)

# Print results
print(f"Accuracy: {accuracy:.2f}")
print("\nConfusion Matrix:")
print(conf_matrix)
print("\nClassification Report:")
print(class_report)

# Train kNN classifier with k=3
k = 3
neigh = KNeighborsClassifier(n_neighbors=k)
neigh.fit(X_train_scaled, y_train)

# Test the accuracy of the classifier using the score method
accuracy = neigh.score(X_test_scaled, y_test)

# Print accuracy
print(f"Accuracy: {accuracy:.2f}")

# Predict class labels for the entire test set
y_pred = neigh.predict(X_test_scaled)
print("\nPredictions for the entire test set:")
print(y_pred)

# Example: Predict the class for a specific test vector
# Choose an example test vector (e.g., the first test vector)
test_vect_index = 0
test_vect = X_test_scaled[test_vect_index]
predicted_class = neigh.predict([test_vect])[0]
actual_class = y_test[test_vect_index]

print(f"\nExample Test Vector Index: {test_vect_index}")
print(f"Actual Class: {actual_class}")
print(f"Predicted Class: {predicted_class}")

# Feature scaling
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# List to store accuracy for each value of k
k_values = list(range(1, 12))
accuracies = []

# Train kNN classifiers for k from 1 to 11
for k in k_values:
    # Create and train kNN classifier
    neigh = KNeighborsClassifier(n_neighbors=k)
    neigh.fit(X_train_scaled, y_train)
    
    # Compute accuracy
    accuracy = neigh.score(X_test_scaled, y_test)
    accuracies.append(accuracy)
    
    # Print accuracy for k
    print(f"Accuracy for k={k}: {accuracy:.2f}")

# Plot accuracy vs k
plt.figure(figsize=(10, 6))
plt.plot(k_values, accuracies, marker='o', linestyle='-', color='b')
plt.xlabel('Number of Neighbors (k)')
plt.ylabel('Accuracy')
plt.title('Accuracy vs. Number of Neighbors')
plt.xticks(k_values)  # Ensure x-axis shows all k values
plt.grid(True)
plt.show()

