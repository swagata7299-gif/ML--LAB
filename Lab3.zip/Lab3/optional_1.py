import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Parameters for normal distribution
mean = 0
std_dev = 1
num_samples = 1000

# Generate normal distribution data
data = np.random.normal(loc=mean, scale=std_dev, size=num_samples)

# Plot histogram
plt.figure(figsize=(12, 6))

# Plot histogram
plt.hist(data, bins=30, density=True, alpha=0.6, color='g', edgecolor='black', label='Histogram')

# Plot normal distribution curve
# Define the range for the x-axis
xmin, xmax = plt.xlim()
x = np.linspace(xmin, xmax, 100)
# Calculate the normal distribution curve
p = (1 / (std_dev * np.sqrt(2 * np.pi))) * np.exp(-0.5 * ((x - mean) / std_dev) ** 2)
plt.plot(x, p, 'k', linewidth=2, label='Normal Distribution Curve')

# Add labels and title
plt.xlabel('Value')
plt.ylabel('Density')
plt.title('Normal Distribution vs Histogram')
plt.legend()

# Show plot
plt.show()
