import pandas as pd
import numpy as np

# Function to evaluate intraclass spread and interclass distances
def evaluate_spread_and_distance(csv_filename):
    df = pd.read_csv(csv_filename)
    
    # Separate features and labels
    features = df.iloc[:, :-2].values.astype(float)  # All columns except last two
    labels = df.iloc[:, -2].values  # Second to last column
    filenames = df.iloc[:, -1].values  # Last column
    
    # Calculate intraclass spread
    intraclass_spreads = {}
    interclass_distances = {}
    
    unique_labels = np.unique(labels)
    
    mean_vectors = {}
    for label in unique_labels:
        class_features = features[labels == label]
        mean_vector = np.mean(class_features, axis=0)
        mean_vectors[label] = mean_vector
        # Calculate the intraclass spread (average distance to mean vector)
        spread = np.mean(np.linalg.norm(class_features - mean_vector, axis=1))
        intraclass_spreads[label] = spread
    
    # Calculate interclass distances
    for label1 in unique_labels:
        for label2 in unique_labels:
            if label1 != label2:
                dist = np.linalg.norm(mean_vectors[label1] - mean_vectors[label2])
                interclass_distances[f"{label1}-{label2}"] = dist
    
    # Display results
    print("\nIntraclass Spread:")
    for label, spread in intraclass_spreads.items():
        print(f"{label}: {spread}")
    
    print("\nInterclass Distances:")
    for classes, distance in interclass_distances.items():
        print(f"{classes}: {distance}")

# Paths
csv_filename = 'image_dataset.csv'  # Replace with your CSV file name

# Evaluate intraclass spread and interclass distances
evaluate_spread_and_distance(csv_filename)

def calculate_class_centroids(csv_filename):
    df = pd.read_csv(csv_filename)
    
    # Separate features and labels
    features = df.iloc[:, :-2].values.astype(float)  # All columns except the last two
    labels = df.iloc[:, -2].values  # Second to last column
    
    # Calculate class centroids
    unique_labels = np.unique(labels)
    centroids = {}
    
    for label in unique_labels:
        class_features = features[labels == label]
        centroid = np.mean(class_features, axis=0)  # Mean feature vector for the class
        centroids[label] = centroid
    
    # Print centroids
    print("\nClass Centroids:")
    for label, centroid in centroids.items():
        print(f"{label}: {centroid}")
    
    return centroids


# Calculate class centroids
centroids = calculate_class_centroids(csv_filename)

# Function to calculate class centroids and spreads
def calculate_class_statistics(csv_filename):
    df = pd.read_csv(csv_filename)
    
    # Separate features and labels
    features = df.iloc[:, :-2].values.astype(float)  # All columns except the last two
    labels = df.iloc[:, -2].values  # Second to last column
    
    # Calculate class centroids and spreads
    unique_labels = np.unique(labels)
    centroids = {}
    spreads = {}
    
    for label in unique_labels:
        class_features = features[labels == label]
        centroid = np.mean(class_features, axis=0)  # Mean feature vector for the class
        spread = np.std(class_features, axis=0)      # Standard deviation vector for the class
        centroids[label] = centroid
        spreads[label] = spread
    
    # Print results
    print("\nClass Centroids:")
    for label, centroid in centroids.items():
        print(f"{label}: {centroid}")
    
    print("\nClass Spreads (Standard Deviations):")
    for label, spread in spreads.items():
        print(f"{label}: {spread}")
    
    return centroids, spreads

# Calculate class centroids and spreads
centroids, spreads = calculate_class_statistics(csv_filename)

import pandas as pd
import numpy as np

# Function to calculate class centroids, spreads, and distances
def calculate_class_statistics(csv_filename):
    df = pd.read_csv(csv_filename)
    
    # Separate features and labels
    features = df.iloc[:, :-2].values.astype(float)  # All columns except the last two
    labels = df.iloc[:, -2].values  # Second to last column
    
    # Calculate class centroids and spreads
    unique_labels = np.unique(labels)
    centroids = {}
    spreads = {}
    
    for label in unique_labels:
        class_features = features[labels == label]
        centroid = np.mean(class_features, axis=0)  # Mean feature vector for the class
        spread = np.std(class_features, axis=0)      # Standard deviation vector for the class
        centroids[label] = centroid
        spreads[label] = spread
    
    # Calculate distances between class centroids
    distances = {}
    for label1 in unique_labels:
        for label2 in unique_labels:
            if label1 != label2:
                dist = np.linalg.norm(centroids[label1] - centroids[label2])
                distances[f"{label1}-{label2}"] = dist
    
    # Print results
    print("\nClass Centroids:")
    for label, centroid in centroids.items():
        print(f"{label}: {centroid}")
    
    print("\nClass Spreads (Standard Deviations):")
    for label, spread in spreads.items():
        print(f"{label}: {spread}")
    
    print("\nDistances Between Class Centroids:")
    for classes, distance in distances.items():
        print(f"{classes}: {distance}")
    
    return centroids, spreads, distances

# Calculate class centroids, spreads, and distances
centroids, spreads, distances = calculate_class_statistics(csv_filename)
