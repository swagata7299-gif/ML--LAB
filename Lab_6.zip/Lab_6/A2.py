import numpy as np
import matplotlib.pyplot as plt

# AND gate inputs and outputs
X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])  # Inputs (X1, X2)
Y = np.array([0, 0, 0, 1])  # Expected outputs for AND gate

# Initial weights and bias
W0 = 10  # Bias
W1 = 0.2
W2 = -0.75
learning_rate = 0.05

# Activation function (Step function)
def step_activation(weighted_sum):
    return 1 if weighted_sum >= 0 else 0

# Perceptron training function
def train_perceptron(X, Y, W0, W1, W2, learning_rate, epochs=100):
    errors = []
    for epoch in range(epochs):
        total_error = 0
        for i in range(len(X)):
            # Weighted sum (net input)
            weighted_sum = W0 + (W1 * X[i][0]) + (W2 * X[i][1])
            
            # Prediction using step activation function
            prediction = step_activation(weighted_sum)
            
            # Error calculation
            error = Y[i] - prediction
            
            # Update weights if there is an error
            W0 = W0 + learning_rate * error  # Update bias
            W1 = W1 + learning_rate * error * X[i][0]  # Update weight W1
            W2 = W2 + learning_rate * error * X[i][1]  # Update weight W2
            
            # Calculate the sum of squared errors
            total_error += error**2
        
        # Append the error for this epoch
        errors.append(total_error)
        
        # If total error is 0, stop the training
        if total_error == 0:
            print(f"Weights converged after {epoch+1} epochs.")
            break
            
    return W0, W1, W2, errors

# Training the perceptron
W0, W1, W2, errors = train_perceptron(X, Y, W0, W1, W2, learning_rate)

# Plotting the errors over epochs
epochs = range(1, len(errors) + 1)
plt.plot(epochs, errors, marker='o')
plt.title("Epochs vs Sum-Squared Error")
plt.xlabel("Epochs")
plt.ylabel("Sum-Squared Error")
plt.grid(True)
plt.show()

# Final weights
print("Final weights after training:")
print(f"W0 (Bias): {W0}, W1: {W1}, W2: {W2}")
