import numpy as np
import pandas as pd
import os
from PIL import Image
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report, accuracy_score

def load_images_from_folder(folder, target_size):
    images = []
    labels = []
    for label in os.listdir(folder):
        label_folder = os.path.join(folder, label)
        if os.path.isdir(label_folder):
            for filename in os.listdir(label_folder):
                img_path = os.path.join(label_folder, filename)
                try:
                    with Image.open(img_path) as img:
                        img = img.resize(target_size)
                        img_array = np.array(img)
                        images.append(img_array.flatten())
                        labels.append(label)
                except Exception as e:
                    print(f"Error loading {img_path}: {e}")
    return np.array(images), np.array(labels)

# Define paths
train_dir = 'data(Final_ML)/train'
test_dir = 'data(Final_ML)/test'

# Load and preprocess images
target_size = (150, 150)  # Resize images to 150x150
X_train, y_train = load_images_from_folder(train_dir, target_size)
X_test, y_test = load_images_from_folder(test_dir, target_size)

# Convert categorical labels to numerical values
label_encoder = LabelEncoder()
y_train = label_encoder.fit_transform(y_train)
y_test = label_encoder.transform(y_test)

# Initialize the MLPClassifier
mlp = MLPClassifier(hidden_layer_sizes=(100,), max_iter=500, random_state=42)

# Train the model
mlp.fit(X_train, y_train)

# Make predictions
y_pred = mlp.predict(X_test)

# Evaluate the model
print("Accuracy:", accuracy_score(y_test, y_pred))
print("Classification Report:\n", classification_report(y_test, y_pred, target_names=label_encoder.classes_))
