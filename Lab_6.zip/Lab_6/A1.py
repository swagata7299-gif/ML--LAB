def summation_unit(inputs, weights, bias):
    weighted_sum = sum([i * w for i, w in zip(inputs, weights)]) + bias
    return weighted_sum

def step_activation(weighted_sum):
    return 1 if weighted_sum >= 0 else 0

def bipolar_step_activation(weighted_sum):
    return 1 if weighted_sum >= 0 else -1

import numpy as np
def sigmoid_activation(weighted_sum):
    return 1 / (1 + np.exp(-weighted_sum))

def tanh_activation(weighted_sum):
    return np.tanh(weighted_sum)

def relu_activation(weighted_sum):
    return max(0, weighted_sum)

def leaky_relu_activation(weighted_sum, alpha=0.01):
    return weighted_sum if weighted_sum > 0 else alpha * weighted_sum

def comparator_unit(predicted, actual):
    error = actual - predicted
    return error

import pandas as pd

# Load dataset
df = pd.read_csv('image_datasets_1.csv')

# Example data points
inputs = df[['mean_R', 'mean_G', 'mean_B']].values
labels = df['label'].apply(lambda x: 1 if x == 'real' else 0).values

# Initialize weights and bias
weights = [0.2, -0.75, 0.5]  # Example weights
bias = 10

learning_rate = 0.05
epochs = 100  # Example value for number of epochs

errors = []

# Training loop
for epoch in range(epochs):
    total_error = 0
    for i in range(len(inputs)):
        input_data = inputs[i]
        actual_label = labels[i]

        # Calculate the weighted sum
        weighted_sum = summation_unit(input_data, weights, bias)

        # Apply activation function (e.g., Sigmoid here)
        predicted_label = sigmoid_activation(weighted_sum)

        # Calculate error
        error = comparator_unit(predicted_label, actual_label)

        # Update weights using gradient descent
        for j in range(len(weights)):
            weights[j] += learning_rate * error * input_data[j]
        bias += learning_rate * error

        # Sum square error for this epoch
        total_error += error ** 2

    # Track error for plotting
    errors.append(total_error)

# Plot errors against epochs
import matplotlib.pyplot as plt
plt.plot(range(epochs), errors)
plt.xlabel('Epochs')
plt.ylabel('Sum Square Error')
plt.title('Error vs Epochs')
plt.show()
