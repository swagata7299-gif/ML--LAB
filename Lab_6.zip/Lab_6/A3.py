import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.special import expit  # This is a numerically stable sigmoid function

# Load the dataset (mean_R, mean_G, mean_B, label)
data = pd.read_csv('image_datasets_1.csv')  # Use appropriate file path for the dataset

# Convert labels ('real' -> 1, 'fake' -> 0)
data['label'] = data['label'].apply(lambda x: 1 if x == 'real' else 0)

# Features (mean_R, mean_G, mean_B) and labels
X = data[['mean_R', 'mean_G', 'mean_B']].values
Y = data['label'].values

# Initial weights and bias
W0 = 10  # Bias
W1 = 0.2
W2 = -0.75
W3 = 0.5  # Adding a third weight for mean_B
learning_rate = 0.05

# Bi-Polar Step Activation Function
def bipolar_step_activation(weighted_sum):
    return 1 if weighted_sum >= 0 else -1

# Sigmoid Activation Function (Modified to handle large values safely)
def sigmoid_activation(weighted_sum):
    # Clip the weighted sum to avoid overflow (keeps values between -500 and 500)
    return expit(np.clip(weighted_sum, -500, 500))

# ReLU Activation Function
def relu_activation(weighted_sum):
    return max(0, weighted_sum)

# Perceptron training function with dynamic activation function
def train_perceptron(X, Y, W0, W1, W2, W3, learning_rate, activation_func, epochs=100):
    errors = []
    for epoch in range(epochs):
        total_error = 0
        for i in range(len(X)):
            # Weighted sum (net input)
            weighted_sum = W0 + (W1 * X[i][0]) + (W2 * X[i][1]) + (W3 * X[i][2])
            
            # Prediction using the given activation function
            prediction = activation_func(weighted_sum)
            
            # Adjust for Bi-Polar Step, treat -1 as 0 for the error calculation
            if activation_func == bipolar_step_activation:
                prediction = 0 if prediction == -1 else 1
            
            # Error calculation
            error = Y[i] - prediction
            
            # Update weights if there is an error
            W0 = W0 + learning_rate * error  # Update bias
            W1 = W1 + learning_rate * error * X[i][0]  # Update weight W1 (mean_R)
            W2 = W2 + learning_rate * error * X[i][1]  # Update weight W2 (mean_G)
            W3 = W3 + learning_rate * error * X[i][2]  # Update weight W3 (mean_B)
            
            # Calculate the sum of squared errors
            total_error += error**2
        
        # Append the error for this epoch
        errors.append(total_error)
        
        # If total error is 0, stop the training
        if total_error == 0:
            print(f"Weights converged after {epoch+1} epochs with {activation_func.__name__}.")
            break
            
    return W0, W1, W2, W3, errors

# Function to train and plot errors for different activation functions
def experiment_activation_functions(X, Y, W0, W1, W2, W3, learning_rate):
    activations = {
        'Bi-Polar Step': bipolar_step_activation,
        'Sigmoid': sigmoid_activation,
        'ReLU': relu_activation
    }
    
    for name, func in activations.items():
        print(f"\nTraining with {name} activation function:")
        W0, W1, W2, W3, errors = train_perceptron(X, Y, W0, W1, W2, W3, learning_rate, func)
        
        # Plotting the errors over epochs
        epochs = range(1, len(errors) + 1)
        plt.plot(epochs, errors, marker='o', label=name)
    
    plt.title("Epochs vs Sum-Squared Error for Different Activation Functions")
    plt.xlabel("Epochs")
    plt.ylabel("Sum-Squared Error")
    plt.legend()
    plt.grid(True)
    plt.show()

# Run the experiment for all activation functions
experiment_activation_functions(X, Y, W0, W1, W2, W3, learning_rate)
