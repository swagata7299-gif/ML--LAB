
import numpy as np
#perceptron_approach
# Data
X = np.array([
    [20, 6, 2, 386],
    [16, 3, 6, 289],
    [27, 6, 2, 393],
    [19, 1, 2, 110],
    [24, 4, 2, 280],
    [22, 1, 5, 167],
    [15, 4, 2, 271],
    [18, 4, 2, 274],
    [21, 1, 4, 148],
    [16, 2, 4, 198]
])

y = np.array([1, 1, 1, 0, 1, 0, 1, 1, 0, 0])

# Initialize weights and bias
np.random.seed(0)
weights = np.random.randn(4)
bias = np.random.randn()

# Sigmoid activation function
def sigmoid(z):
    return 1 / (1 + np.exp(-z))

# Derivative of sigmoid
def sigmoid_derivative(z):
    return sigmoid(z) * (1 - sigmoid(z))

# Training parameters
learning_rate = 0.01
epochs = 1000

# Training loop
for epoch in range(epochs):
    # Forward pass
    z = np.dot(X, weights) + bias
    predictions = sigmoid(z)
    
    # Compute loss (binary cross-entropy)
    loss = -np.mean(y * np.log(predictions + 1e-8) + (1 - y) * np.log(1 - predictions + 1e-8))
    
    # Backward pass
    error = predictions - y
    weight_gradient = np.dot(X.T, error * sigmoid_derivative(z)) / len(y)
    bias_gradient = np.mean(error * sigmoid_derivative(z))
    
    # Update weights and bias
    weights -= learning_rate * weight_gradient
    bias -= learning_rate * bias_gradient
    
    if epoch % 100 == 0:
        print(f'Epoch {epoch}, Loss: {loss}')

# Testing the model
test_data = np.array([
    [20, 6, 2, 386],
    [16, 3, 6, 289],
    [27, 6, 2, 393],
    [19, 1, 2, 110],
    [24, 4, 2, 280],
    [22, 1, 5, 167],
    [15, 4, 2, 271],
    [18, 4, 2, 274],
    [21, 1, 4, 148],
    [16, 2, 4, 198]
])

predictions = sigmoid(np.dot(test_data, weights) + bias)
print('Predictions:', predictions)


#pseudo-inverse_approach
import numpy as np

# Data
X = np.array([
    [20, 6, 2, 386],
    [16, 3, 6, 289],
    [27, 6, 2, 393],
    [19, 1, 2, 110],
    [24, 4, 2, 280],
    [22, 1, 5, 167],
    [15, 4, 2, 271],
    [18, 4, 2, 274],
    [21, 1, 4, 148],
    [16, 2, 4, 198]
])

y = np.array([1, 1, 1, 0, 1, 0, 1, 1, 0, 0])

# Add bias column to X
X_b = np.c_[np.ones((X.shape[0], 1)), X]

# Compute weights using pseudo-inverse
pseudo_inv = np.linalg.pinv(X_b)
weights_pseudo_inv = np.dot(pseudo_inv, y)

# Extract bias and weights
bias_pseudo_inv = weights_pseudo_inv[0]
weights_pseudo_inv = weights_pseudo_inv[1:]

# Make predictions
def predict(X, weights, bias):
    z = np.dot(X, weights) + bias
    return sigmoid(z)

predictions_pseudo_inv = predict(X, weights_pseudo_inv, bias_pseudo_inv)

# Threshold predictions
predictions_class = (predictions_pseudo_inv > 0.5).astype(int)

print('Weights (Pseudo-Inverse):', weights_pseudo_inv)
print('Bias (Pseudo-Inverse):', bias_pseudo_inv)
print('Predictions (Pseudo-Inverse):', predictions_class)


#comparison between perceptron_model and pseudo-inverse model
# Assume perceptron weights and bias
weights_perceptron = np.array([0.1, 0.2, 0.3, 0.4])  # Example values
bias_perceptron = 0.5  # Example value

# Make predictions using perceptron
predictions_perceptron = predict(X, weights_perceptron, bias_perceptron)
predictions_class_perceptron = (predictions_perceptron > 0.5).astype(int)

# Calculate accuracy
accuracy_perceptron = np.mean(predictions_class_perceptron == y)
accuracy_pseudo_inv = np.mean(predictions_class == y)

print('Accuracy (Perceptron):', accuracy_perceptron)
print('Accuracy (Pseudo-Inverse):', accuracy_pseudo_inv)

# Print predictions for comparison
print('Predictions (Perceptron):', predictions_class_perceptron)
print('Predictions (Pseudo-Inverse):', predictions_class)
