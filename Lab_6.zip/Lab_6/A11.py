import numpy as np
from sklearn.neural_network import MLPClassifier
import matplotlib.pyplot as plt

#AND Gate MLP
# Define the AND gate data
X_and = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
y_and = np.array([0, 0, 0, 1])  # Output for AND gate

# Initialize and train the MLPClassifier
mlp_and = MLPClassifier(hidden_layer_sizes=(2,), activation='relu', solver='adam', learning_rate_init=0.05, max_iter=1000)
mlp_and.fit(X_and, y_and)

# Make predictions
predictions_and = mlp_and.predict(X_and)
print("AND Gate Predictions:")
for i, pred in enumerate(predictions_and):
    print(f"Input: {X_and[i]}, Predicted Output: {pred}")

# Plotting decision boundary for visualization
import matplotlib.pyplot as plt
import numpy as np

def plot_decision_boundary(X, y, model):
    h = .02  # step size in the mesh
    x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
    y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
    xx, yy = np.meshgrid(np.arange(x_min, x_max, h),
                         np.arange(y_min, y_max, h))
    Z = model.predict(np.c_[xx.ravel(), yy.ravel()])
    Z = Z.reshape(xx.shape)
    plt.contourf(xx, yy, Z, alpha=0.8)
    plt.scatter(X[:, 0], X[:, 1], c=y, edgecolors='k', marker='o')
    plt.xlabel('Feature 1')
    plt.ylabel('Feature 2')
    plt.title('Decision Boundary for AND Gate')
    plt.show()

plot_decision_boundary(X_and, y_and, mlp_and)

#XOR Gate MLP
import numpy as np
from sklearn.neural_network import MLPClassifier
import matplotlib.pyplot as plt

# Define the XOR gate data
X_xor = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
y_xor = np.array([0, 1, 1, 0])  # Output for XOR gate

# Initialize and train the MLPClassifier
mlp_xor = MLPClassifier(hidden_layer_sizes=(2,), activation='relu', solver='adam', learning_rate_init=0.05, max_iter=10000)
mlp_xor.fit(X_xor, y_xor)

# Make predictions
predictions_xor = mlp_xor.predict(X_xor)
print("XOR Gate Predictions:")
for i, pred in enumerate(predictions_xor):
    print(f"Input: {X_xor[i]}, Predicted Output: {pred}")

# Plotting decision boundary for visualization
def plot_decision_boundary(X, y, model):
    h = .02  # step size in the mesh
    x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
    y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
    xx, yy = np.meshgrid(np.arange(x_min, x_max, h),
                         np.arange(y_min, y_max, h))
    Z = model.predict(np.c_[xx.ravel(), yy.ravel()])
    Z = Z.reshape(xx.shape)
    plt.contourf(xx, yy, Z, alpha=0.8)
    plt.scatter(X[:, 0], X[:, 1], c=y, edgecolors='k', marker='o')
    plt.xlabel('Feature 1')
    plt.ylabel('Feature 2')
    plt.title('Decision Boundary for XOR Gate')
    plt.show()

plot_decision_boundary(X_xor, y_xor, mlp_xor)
