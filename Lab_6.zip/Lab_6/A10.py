import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Define activation functions and their derivatives
def sigmoid_activation(weighted_sum):
    return 1 / (1 + np.exp(-weighted_sum))

def sigmoid_derivative(output):
    return output * (1 - output)

def summation_unit(inputs, weights, bias):
    weighted_sum = np.dot(inputs, weights) + bias
    return weighted_sum

def comparator_unit(predicted, actual):
    error = actual - predicted
    return error

# Load dataset
df = pd.read_csv('image_datasets_1.csv')

# Example data points
inputs = df[['mean_R', 'mean_G', 'mean_B']].values
labels = df['label'].apply(lambda x: [1, 0] if x == 'real' else [0, 1]).values  # Convert labels to [1, 0] and [0, 1]

# Initialize weights and biases
input_neurons = 3
hidden_neurons = 2
output_neurons = 2
learning_rate = 0.05
epochs = 100

# Initialize weights and biases for a simple network with one hidden layer
weights_input_hidden = np.random.rand(input_neurons, hidden_neurons)
weights_hidden_output = np.random.rand(hidden_neurons, output_neurons)
bias_hidden = np.random.rand(hidden_neurons)
bias_output = np.random.rand(output_neurons)

errors = []

# Training loop
for epoch in range(epochs):
    total_error = 0
    for i in range(len(inputs)):
        input_data = inputs[i]
        actual_label = labels[i]

        # Forward pass
        hidden_layer_input = summation_unit(input_data, weights_input_hidden, bias_hidden)
        hidden_layer_output = sigmoid_activation(hidden_layer_input)
        
        output_layer_input = summation_unit(hidden_layer_output, weights_hidden_output, bias_output)
        predicted_label = sigmoid_activation(output_layer_input)

        # Calculate error
        error = comparator_unit(predicted_label, actual_label)
        total_error += np.sum(error ** 2)
        
        # Backward pass (Backpropagation)
        # Output layer gradients
        d_predicted_output = error * sigmoid_derivative(predicted_label)
        weights_hidden_output += learning_rate * np.dot(hidden_layer_output.reshape(-1, 1), d_predicted_output.reshape(1, -1))
        bias_output += learning_rate * d_predicted_output
        
        # Hidden layer gradients
        d_hidden_layer = np.dot(d_predicted_output, weights_hidden_output.T) * sigmoid_derivative(hidden_layer_output)
        weights_input_hidden += learning_rate * np.outer(input_data, d_hidden_layer)
        bias_hidden += learning_rate * d_hidden_layer
    
    errors.append(total_error)

# Plot errors against epochs
plt.plot(range(epochs), errors)
plt.xlabel('Epochs')
plt.ylabel('Sum Square Error')
plt.title('Error vs Epochs')
plt.show()

# Testing the trained neural network
print('Predicted Output:')
for x in inputs:
    hidden_layer_input = summation_unit(x, weights_input_hidden, bias_hidden)
    hidden_layer_output = sigmoid_activation(hidden_layer_input)
    
    output_layer_input = summation_unit(hidden_layer_output, weights_hidden_output, bias_output)
    predicted_output = sigmoid_activation(output_layer_input)
    
    print(f'Input: {x}, Predicted Output: {predicted_output}')

#A2 modification for two output
import numpy as np
import matplotlib.pyplot as plt

# XOR gate inputs and outputs
X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
Y = np.array([[1, 0], [0, 1], [0, 1], [1, 0]])  # Expected outputs for XOR gate with two output nodes

# Initialize weights and bias
input_neurons = 2
hidden_neurons = 2
output_neurons = 2
learning_rate = 0.05
epochs = 10000

# Initialize weights and biases
np.random.seed(0)  # For reproducibility
weights_input_hidden = np.random.rand(input_neurons, hidden_neurons)
weights_hidden_output = np.random.rand(hidden_neurons, output_neurons)
bias_hidden = np.random.rand(hidden_neurons)
bias_output = np.random.rand(output_neurons)

errors = []

# Training loop
for epoch in range(epochs):
    total_error = 0
    for i in range(len(X)):
        input_data = X[i]
        actual_label = Y[i]

        # Forward pass
        hidden_layer_input = summation_unit(input_data, weights_input_hidden, bias_hidden)
        hidden_layer_output = sigmoid_activation(hidden_layer_input)
        
        output_layer_input = summation_unit(hidden_layer_output, weights_hidden_output, bias_output)
        predicted_output = sigmoid_activation(output_layer_input)

        # Calculate error
        error = comparator_unit(predicted_output, actual_label)
        total_error += np.sum(error ** 2)
        
        # Backward pass (Backpropagation)
        # Output layer gradients
        d_predicted_output = error * sigmoid_derivative(predicted_output)
        weights_hidden_output += learning_rate * np.dot(hidden_layer_output.reshape(-1, 1), d_predicted_output.reshape(1, -1))
        bias_output += learning_rate * d_predicted_output
        
        # Hidden layer gradients
        d_hidden_layer = np.dot(d_predicted_output, weights_hidden_output.T) * sigmoid_derivative(hidden_layer_output)
        weights_input_hidden += learning_rate * np.outer(input_data, d_hidden_layer)
        bias_hidden += learning_rate * d_hidden_layer
    
    errors.append(total_error)

# Plot errors against epochs
plt.plot(range(epochs), errors)
plt.xlabel('Epochs')
plt.ylabel('Sum Square Error')
plt.title('Error vs Epochs')
plt.show()

# Testing the trained neural network
print('Predicted Output:')
for x in X:
    hidden_layer_input = summation_unit(x, weights_input_hidden, bias_hidden)
    hidden_layer_output = sigmoid_activation(hidden_layer_input)
    
    output_layer_input = summation_unit(hidden_layer_output, weights_hidden_output, bias_output)
    predicted_output = sigmoid_activation(output_layer_input)
    
    print(f'Input: {x}, Predicted Output: {predicted_output}')
