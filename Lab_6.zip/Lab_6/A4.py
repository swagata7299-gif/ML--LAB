import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Load dataset
df = pd.read_csv('image_datasets_1.csv')

# Extract features and labels
inputs = df[['mean_R', 'mean_G', 'mean_B']].values
labels = df['label'].apply(lambda x: 1 if x == 'real' else 0).values

# Define a summation unit
def summation_unit(inputs, weights, bias):
    return np.dot(inputs, weights) + bias

# Activation function (Sigmoid in this case, you can change to others)
def sigmoid_activation(weighted_sum):
    return 1 / (1 + np.exp(-weighted_sum))

# Error comparator unit
def comparator_unit(predicted, actual):
    return actual - predicted

# Train function with varying learning rates
def train_perceptron(learning_rate, max_epochs=1000, tolerance=1e-3):
    weights = np.array([0.2, -0.75, 0.5])  # Initial weights
    bias = 10  # Initial bias
    epochs = 0
    
    for epoch in range(max_epochs):
        total_error = 0
        for i in range(len(inputs)):
            input_data = inputs[i]
            actual_label = labels[i]
            
            # Calculate weighted sum
            weighted_sum = summation_unit(input_data, weights, bias)
            
            # Apply activation function (Sigmoid here)
            predicted_label = sigmoid_activation(weighted_sum)
            
            # Calculate error
            error = comparator_unit(predicted_label, actual_label)
            total_error += error ** 2
            
            # Update weights and bias
            for j in range(len(weights)):
                weights[j] += learning_rate * error * input_data[j]
            bias += learning_rate * error
        
        epochs += 1
        
        # Convergence condition (small enough total error)
        if total_error < tolerance:
            break
            
    return epochs  # Return the number of epochs taken for convergence

# Learning rates to test
learning_rates = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
epochs_for_convergence = []

# Test for each learning rate
for lr in learning_rates:
    epochs = train_perceptron(learning_rate=lr)
    epochs_for_convergence.append(epochs)

# Plot learning rates vs. epochs for convergence
plt.plot(learning_rates, epochs_for_convergence, marker='o')
plt.xlabel('Learning Rate')
plt.ylabel('Epochs to Converge')
plt.title('Learning Rate vs. Epochs to Converge')
plt.grid(True)
plt.show()
