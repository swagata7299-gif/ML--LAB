import numpy as np

# Data
X = np.array([
    [20, 6, 2, 386],
    [16, 3, 6, 289],
    [27, 6, 2, 393],
    [19, 1, 2, 110],
    [24, 4, 2, 280],
    [22, 1, 5, 167],
    [15, 4, 2, 271],
    [18, 4, 2, 274],
    [21, 1, 4, 148],
    [16, 2, 4, 198]
])

y = np.array([1, 1, 1, 0, 1, 0, 1, 1, 0, 0])

# Initialize weights and bias
np.random.seed(0)
weights = np.random.randn(4)
bias = np.random.randn()

# Sigmoid activation function
def sigmoid(z):
    return 1 / (1 + np.exp(-z))

# Derivative of sigmoid
def sigmoid_derivative(z):
    return sigmoid(z) * (1 - sigmoid(z))

# Training parameters
learning_rate = 0.01
epochs = 1000

# Training loop
for epoch in range(epochs):
    # Forward pass
    z = np.dot(X, weights) + bias
    predictions = sigmoid(z)
    
    # Compute loss (binary cross-entropy)
    loss = -np.mean(y * np.log(predictions + 1e-8) + (1 - y) * np.log(1 - predictions + 1e-8))
    
    # Backward pass
    error = predictions - y
    weight_gradient = np.dot(X.T, error * sigmoid_derivative(z)) / len(y)
    bias_gradient = np.mean(error * sigmoid_derivative(z))
    
    # Update weights and bias
    weights -= learning_rate * weight_gradient
    bias -= learning_rate * bias_gradient
    
    if epoch % 100 == 0:
        print(f'Epoch {epoch}, Loss: {loss}')

# Testing the model
test_data = np.array([
    [20, 6, 2, 386],
    [16, 3, 6, 289],
    [27, 6, 2, 393],
    [19, 1, 2, 110],
    [24, 4, 2, 280],
    [22, 1, 5, 167],
    [15, 4, 2, 271],
    [18, 4, 2, 274],
    [21, 1, 4, 148],
    [16, 2, 4, 198]
])

predictions = sigmoid(np.dot(test_data, weights) + bias)
print('Predictions:', predictions)
