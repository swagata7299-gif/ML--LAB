import numpy as np
import matplotlib.pyplot as plt

# Define activation functions and their derivatives
def sigmoid_activation(weighted_sum):
    return 1 / (1 + np.exp(-weighted_sum))

def sigmoid_derivative(output):
    return output * (1 - output)

def summation_unit(inputs, weights, bias):
    weighted_sum = np.dot(inputs, weights) + bias
    return weighted_sum

# XOR Gate Data
X = np.array([
    [0, 0],
    [0, 1],
    [1, 0],
    [1, 1]
])

y = np.array([[0], [1], [1], [0]])

# Initialize weights and biases for the network
input_layer_neurons = 2
hidden_layer_neurons = 2
output_layer_neurons = 1
learning_rate = 0.05
epochs = 10000

# Initialize weights and biases
np.random.seed(0)  # For reproducibility
weights_input_hidden = np.random.rand(input_layer_neurons, hidden_layer_neurons)
weights_hidden_output = np.random.rand(hidden_layer_neurons, output_layer_neurons)
bias_hidden = np.random.rand(hidden_layer_neurons)
bias_output = np.random.rand(output_layer_neurons)

errors = []

# Training loop
for epoch in range(epochs):
    total_error = 0
    for i in range(len(X)):
        # Forward pass
        hidden_layer_input = summation_unit(X[i], weights_input_hidden, bias_hidden)
        hidden_layer_output = sigmoid_activation(hidden_layer_input)
        
        output_layer_input = summation_unit(hidden_layer_output, weights_hidden_output, bias_output)
        predicted_output = sigmoid_activation(output_layer_input)
        
        # Calculate error
        error = y[i] - predicted_output
        total_error += np.sum(error ** 2)
        
        # Backward pass (Backpropagation)
        # Output layer gradients
        d_predicted_output = error * sigmoid_derivative(predicted_output)
        weights_hidden_output += learning_rate * np.dot(hidden_layer_output.reshape(-1, 1), d_predicted_output.reshape(1, -1))
        bias_output += learning_rate * d_predicted_output
        
        # Hidden layer gradients
        d_hidden_layer = np.dot(d_predicted_output, weights_hidden_output.T) * sigmoid_derivative(hidden_layer_output)
        weights_input_hidden += learning_rate * np.outer(X[i], d_hidden_layer)
        bias_hidden += learning_rate * d_hidden_layer
    
    # Track error for plotting
    errors.append(total_error)

# Plot errors against epochs
plt.plot(range(epochs), errors)
plt.xlabel('Epochs')
plt.ylabel('Sum Square Error')
plt.title('Error vs Epochs')
plt.show()

# Testing the trained neural network
print('Predicted Output:')
for x in X:
    hidden_layer_input = summation_unit(x, weights_input_hidden, bias_hidden)
    hidden_layer_output = sigmoid_activation(hidden_layer_input)
    
    output_layer_input = summation_unit(hidden_layer_output, weights_hidden_output, bias_output)
    predicted_output = sigmoid_activation(output_layer_input)
    
    print(f'Input: {x}, Predicted Output: {predicted_output}')
