import numpy as np

# Summation Unit
def summation_unit(inputs, weights, bias):
    return sum(i * w for i, w in zip(inputs, weights)) + bias

# Activation Functions
def step_activation(weighted_sum):
    return 1 if weighted_sum >= 0 else 0

def sigmoid_activation(weighted_sum):
    return 1 / (1 + np.exp(-weighted_sum))

# Error Calculation
def error_calculation(expected_output, actual_output):
    return expected_output - actual_output

# XOR Perceptron with Two Layers
def xor_perceptron(inputs, expected_outputs, weights_input_hidden, weights_hidden_output, bias_hidden, bias_output, learning_rate, epochs, activation_func):
    for epoch in range(epochs):
        total_error = 0
        for i in range(len(inputs)):
            # Forward pass
            hidden_layer_outputs = []
            for j in range(len(weights_input_hidden)):
                weighted_sum_hidden = summation_unit(inputs[i], weights_input_hidden[j], bias_hidden[j])
                hidden_output = activation_func(weighted_sum_hidden)
                hidden_layer_outputs.append(hidden_output)
            
            # Calculate output layer
            weighted_sum_output = summation_unit(hidden_layer_outputs, weights_hidden_output, bias_output)
            predicted_output = activation_func(weighted_sum_output)
            
            # Error calculation
            error = error_calculation(expected_outputs[i], predicted_output)
            total_error += error ** 2
            
            # Backpropagation: Update weights for the output layer
            for j in range(len(weights_hidden_output)):
                weights_hidden_output[j] += learning_rate * error * hidden_layer_outputs[j]
            bias_output += learning_rate * error
            
            # Backpropagation: Update weights for the hidden layer
            for j in range(len(weights_input_hidden)):
                for k in range(len(weights_input_hidden[j])):
                    weights_input_hidden[j][k] += learning_rate * error * inputs[i][k]
                bias_hidden[j] += learning_rate * error
        
        # If total error becomes 0, convergence is achieved
        if total_error == 0:
            break

    return weights_input_hidden, weights_hidden_output, bias_hidden, bias_output, epoch

# XOR Training Data
inputs = [(0, 0), (0, 1), (1, 0), (1, 1)]
expected_outputs = [0, 1, 1, 0]

# Initial Weights and Biases
weights_input_hidden = [[0.2, -0.4], [-0.5, 0.3]]  # Two perceptrons in the hidden layer
weights_hidden_output = [0.6, -0.7]  # Single output perceptron
bias_hidden = [0.1, -0.3]
bias_output = 0.2
learning_rate = 0.05
epochs = 10000

# Using Sigmoid Activation Function
weights_input_hidden, weights_hidden_output, bias_hidden, bias_output, epoch = xor_perceptron(
    inputs, expected_outputs, weights_input_hidden, weights_hidden_output, bias_hidden, bias_output, 
    learning_rate, epochs, sigmoid_activation)

print(f"Training completed in {epoch} epochs.")
print(f"Weights Input to Hidden: {weights_input_hidden}")
print(f"Weights Hidden to Output: {weights_hidden_output}")
print(f"Bias Hidden: {bias_hidden}")
print(f"Bias Output: {bias_output}")
