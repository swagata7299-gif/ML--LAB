import numpy as np

# Sigmoid activation function and its derivative
def sigmoid(x):
    return 1 / (1 + np.exp(-x))

def sigmoid_derivative(x):
    return x * (1 - x)

# Define neural network parameters
input_layer_neurons = 2  # Number of input neurons
hidden_layer_neurons = 2 # Number of hidden neurons
output_layer_neurons = 1 # Number of output neurons
learning_rate = 0.05
epochs = 10000

# Initialize weights and biases
np.random.seed(0)  # For reproducibility
weights_input_hidden = np.random.rand(input_layer_neurons, hidden_layer_neurons)
weights_hidden_output = np.random.rand(hidden_layer_neurons, output_layer_neurons)
bias_hidden = np.random.rand(hidden_layer_neurons)
bias_output = np.random.rand(output_layer_neurons)

# Training data for AND gate
X = np.array([
    [0, 0],
    [0, 1],
    [1, 0],
    [1, 1]
])

y = np.array([[0], [0], [0], [1]])

# Training the neural network
for epoch in range(epochs):
    # Forward pass
    hidden_layer_input = np.dot(X, weights_input_hidden) + bias_hidden
    hidden_layer_output = sigmoid(hidden_layer_input)
    
    output_layer_input = np.dot(hidden_layer_output, weights_hidden_output) + bias_output
    predicted_output = sigmoid(output_layer_input)
    
    # Compute the loss (mean squared error)
    error = y - predicted_output
    loss = np.mean(np.square(error))
    
    # Backward pass (Backpropagation)
    # Output layer gradients
    d_predicted_output = error * sigmoid_derivative(predicted_output)
    weights_hidden_output += np.dot(hidden_layer_output.T, d_predicted_output) * learning_rate
    bias_output += np.sum(d_predicted_output, axis=0) * learning_rate
    
    # Hidden layer gradients
    d_hidden_layer = np.dot(d_predicted_output, weights_hidden_output.T) * sigmoid_derivative(hidden_layer_output)
    weights_input_hidden += np.dot(X.T, d_hidden_layer) * learning_rate
    bias_hidden += np.sum(d_hidden_layer, axis=0) * learning_rate
    
    if epoch % 1000 == 0:
        print(f'Epoch {epoch}, Loss: {loss}')

# Testing the trained neural network
hidden_layer_input = np.dot(X, weights_input_hidden) + bias_hidden
hidden_layer_output = sigmoid(hidden_layer_input)

output_layer_input = np.dot(hidden_layer_output, weights_hidden_output) + bias_output
predicted_output = sigmoid(output_layer_input)

print('Predicted Output:')
print(predicted_output)
